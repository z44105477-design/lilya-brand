/* ============================================================
   noest-data.js
   Shared reference data for NOEST EXPRESS integration.
   Used by BOTH index.html (customer order form) and admin.html
   (sending the order to Noest with the correct wilaya code).
   ============================================================ */

/* Official Algerian wilaya code (1-58) for every wilaya name used
   in the site's WILAYAS pricing list. This is what Noest / the
   courier API expects as "wilayaCode" — it is NOT the same as the
   internal "code" used only to sort/select the delivery price row. */
const WILAYA_OFFICIAL_CODE = {
  "Adrar":1, "Chlef":2, "Laghouat":3, "Oum El Bouagui":4, "Batna":5,
  "Bejaia":6, "Biskra":7, "Bechar":8, "Blida":9, "Bouira":10,
  "Tamanrasset":11, "Tebessa":12, "Tlemcen":13, "Tiaret":14, "Tizi Ouzou":15,
  "Alger":16, "Djelfa":17, "Jijel":18, "Setif":19, "Saida":20,
  "Skikda":21, "Sidi Bel Abbes":22, "Annaba":23, "Guelma":24, "Constantine":25,
  "Médéa":26, "Mostaganem":27, "M'Sila":28, "Mascara":29, "Ouargla":30,
  "Oran":31, "El Bayadh":32, "illizi":33, "Bordj Bou Arreridj":34, "Boumerdès":35,
  "El Tarf":36, "Tindouf":37, "Tissemsilt":38, "El Oued":39, "Kenchela":40,
  "Souk Ahrass":41, "Tipaza":42, "Mila":43, "Ain Defla":44, "Naama":45,
  "Ain Temouchent":46, "Ghardaïa":47, "Relizane":48, "Timimoun":49,
  "Ouled Djellal":51, "Beni Abbes":52, "In Salah":53, "Touggourt":55,
  "Djanet":56, "El M'Ghair":57, "El Meniaa":58
};

/* NOEST EXPRESS stop-desk / delivery office directory, extracted from
   the official "دليل مكاتب التوصيل للولايات" (delivery offices directory).
   wilayaCode = official Algerian wilaya code (see above).
   area       = the local name of the office shown in parentheses in the
                directory (e.g. "Barika" for Batna «Barika»), null = main office.
   code       = Noest's own desk code (wilaya number + letter), used as
                stopDeskId when creating a "stopdesk" order. */
const NOEST_OFFICES = [
  {wilayaCode:1, area:null, code:"01A", address:"Centre-ville, à côté de l'ancien magasin Hadj Grifa, en face du centre commercial, quartier El Hattaba – Adrar", phone:"0550602181 / 0561623531"},

  {wilayaCode:2, area:null, code:"02A", address:"Rue Lac des Forêts (À côté du CNRC)", phone:"0770582116 / 0561686360"},
  {wilayaCode:2, area:"Ténès", code:"02B", address:"Rue de Cherchell, en face de l'école primaire les frères Menad, Ténès", phone:"0560469155"},

  {wilayaCode:3, area:null, code:"03A", address:"Quartier El-Wiam – en face de l'Enfance assistée (à 100 m de l'ancien bureau)", phone:"0550600359 / 0770611585"},
  {wilayaCode:3, area:"Aflou", code:"03B", address:"Rue Al-Gaada, à côté de la boulangerie Belkhair", phone:"0550314898"},

  {wilayaCode:4, area:"Aïn Mlila", code:"04A", address:"Cité El Hanaa, route du Lycée Messas", phone:"0561848298"},
  {wilayaCode:4, area:null, code:"04B", address:"Cité 176 logements LSP, Bâtiment 13 – Oum El Bouaghi", phone:"0560445954 / 0560445855"},
  {wilayaCode:4, area:"Aïn El Beïda", code:"04C", address:"Aïn Beïda, en face C.N.A.S, à côté de la Pharmacie Belambri", phone:"0664093739 / 0541149891"},

  {wilayaCode:5, area:null, code:"05A", address:"Cité Meddour Kchida, en face les bâtiments 500", phone:"0560105318 / 0561929074 / 0770605118"},
  {wilayaCode:5, area:"Barika", code:"05B", address:"Quartier Chaabani, en face notaire Bachir Farhani, à côté d'Algérie Télécom", phone:"0560183389 / 0560183413 / 0560183206"},
  {wilayaCode:5, area:null, code:"05C", address:"Cité 1200 logements Oulmi, en face la nouvelle poste et station pétro Baraka", phone:"0563033092 / 0563033091 / 0770881575"},

  {wilayaCode:6, area:null, code:"06A", address:"Rue des frères Tabet, à 20 mètres de l'hôtel Golden H, en face la nouvelle promotion Nid d'Abeille", phone:"0561686346 / 0550429286 / 0561871121"},
  {wilayaCode:6, area:"Akbou", code:"06B", address:"Rue Hibouche – Arafou, en face Djurdjura Cars et Alliance Assurance", phone:"0555589102 / 0555589207"},
  {wilayaCode:6, area:"El Kseur", code:"06C", address:"Rue Hamaoui Hamid, commune El-Kseur, Béjaïa (en face la Sempac El Kseur)", phone:"0563026724 / 0563026713"},

  {wilayaCode:7, area:null, code:"07A", address:"N° 05, cité El Boustène (Haï El Moudjahidine), en face du Centre de formation et d'intervention rapide de la police", phone:"0770608890"},

  {wilayaCode:8, area:null, code:"08A", address:"Cité 622 Logements Al Badr N°02, Bloc 52 (derrière la radio El Saoura / en face la protection civile)", phone:"0561686335 / 0550429404"},

  {wilayaCode:9, area:null, code:"09A", address:"El Ramoule, à côté de la nouvelle gare routière", phone:"0561686325 / 0550600998 / 0561638691"},
  {wilayaCode:9, area:"Boufarik", code:"09B", address:"La résidence Belkbir, en face la salle des fêtes Layalina", phone:"0555589398 / 0555589395"},
  {wilayaCode:9, area:"Mouzaïa", code:"09C", address:"54 logements LPP, en face lycée Kacem Naït Kacem, Mouzaïa", phone:"0560004779 / 0560007949"},

  {wilayaCode:10, area:null, code:"10A", address:"Villa Hamzaoui, Ammar Khodja, Bouira", phone:"0770801024 / 0550428219"},
  {wilayaCode:10, area:"Lakhdaria", code:"10B", address:"Route nationale n°05, projet 55 logts social participatif BT A, Lakhdaria (monté Tizi El Bir, à côté du dépôt de vente semoule MAMA)", phone:"0770170513 / 0563026714"},

  {wilayaCode:11, area:null, code:"11A", address:"Quartier Moulay Omar, derrière le siège de la Daïra, à côté du parking de la Direction des Travaux Publics", phone:"0561638680 / 0560608162 / 0770749607 / 0770820674"},

  {wilayaCode:12, area:null, code:"12A", address:"À côté du 2ème commissariat de police et du magasin de meubles Redel, Tébessa", phone:"0770613002 / 0550602622"},
  {wilayaCode:12, area:"El Ouenza", code:"12B", address:"Cité EPLF, à côté du service des eaux", phone:"0560004704"},

  {wilayaCode:13, area:null, code:"13A", address:"Les Dhalias 426, El Kiffane, Tlemcen", phone:"0561660040 / 0561808143 / 0770750242 / 0560851262 / 0560857684 / 0560912307"},
  {wilayaCode:13, area:"Maghnia", code:"13B", address:"Ouled Ben Saber, à côté du restaurant Raïs", phone:""},

  {wilayaCode:14, area:null, code:"14A", address:"Cité 180 logements CNT, local 01 N° 63, Tiaret", phone:"0550429624 / 0560350227"},
  {wilayaCode:14, area:"Frenda", code:"14B", address:"Cité 60 logements D121, GP 82, Frenda", phone:"0560265156 / 0560265357"},

  {wilayaCode:15, area:null, code:"15A", address:"Cité 450 logements, Nouvelle Ville, en face la salle des fêtes Lilya", phone:"0561623528 / 0550429176"},
  {wilayaCode:15, area:"Azazga", code:"15B", address:"Route nationale N°12, Taddart", phone:"0561906076 / 0561906289"},
  {wilayaCode:15, area:"Draa Ben Khedda", code:"15C", address:"Coopérative El Wouroud, en face A.D.E et ANEM de Draa Ben Khedda", phone:"0770127536 / 0770127817"},

  {wilayaCode:16, area:"Bir Mourad Raïs", code:"16A", address:"02, Lotissement Beau Séjour, Bir Mourad Raïs", phone:"0770610277 / 0560158799"},
  {wilayaCode:16, area:"Bab Ezzouar", code:"16B", address:"Devant la clinique médicale, en face l'école Hilal School", phone:"0560301762 / 0770608746 / 0770615054"},
  {wilayaCode:16, area:"Chéraga", code:"16C", address:"Place Iben Badis N° 03, RDC, Chéraga", phone:"0560846037 / 0560812936"},
  {wilayaCode:16, area:"Reghaïa", code:"16D", address:"822 Logmts LPP Amirouche, Bâtiment A7 N°04, rez-de-chaussée, Reghaïa", phone:"0560441770 / 0560441926 / 0561680248"},
  {wilayaCode:16, area:"Centre Sacré-Cœur", code:"16E", address:"22 Rue Hocine Beladjel, Sacré-Cœur, Alger Centre (en face la banque BADR)", phone:"0560181237 / 0560181433 / 0560181730 / 0560181471"},
  {wilayaCode:16, area:"Baba Hassen", code:"16F", address:"Cité Cherchali Boualam, à côté du croissant rouge, Baba Hassen", phone:"0560182594 / 0560182915 / 0560183036"},
  {wilayaCode:16, area:"Baraki", code:"16G", address:"Baraki, route de Larbaâ, entre la mosquée El Bachir El Ibrahimi et le commissariat", phone:"0560158882 / 0560158961 / 0560158953"},
  {wilayaCode:16, area:"Bordj El Bahri", code:"16H", address:"Cité Galoul, lotissement coopératif immobilier, n° 428", phone:"0563029129 / 0563029128"},
  {wilayaCode:16, area:"Zéralda", code:"16I", address:"Local N, Cité 62, local LPP BTN 5C, 02/03 RDC, Zéralda", phone:"0563029229 / 0560262242"},
  {wilayaCode:16, area:"Birkhadem", code:"16J", address:"Birkhadem, El Malha", phone:"0560004746"},
  {wilayaCode:16, area:"Hussein Dey", code:"16K", address:"Rue Layache Yahia N°06, Hussein Dey, en face mosquée de Brossette", phone:"0770006944 / 0560432083"},

  {wilayaCode:17, area:null, code:"17A", address:"Centre-ville, en face de la Caisse Nationale des Retraites (CNR), quartier Ben Djerma", phone:"0770580860 / 0550429422"},
  {wilayaCode:17, area:"Aïn Oussara", code:"17B", address:"Quartier Mohamed Boudiaf, Section 23, Local n° 30, commune de Aïn Oussara", phone:"0549746237 / 0770941332 / 0778550473"},

  {wilayaCode:18, area:null, code:"18A", address:"Rue 26, avenue Kaoula Mokhtar, Haï Idari", phone:"0770613439 / 0561660019"},
  {wilayaCode:18, area:"El Milia", code:"18B", address:"5 Juillet, rue du stade El Milia, à côté de la protection civile", phone:"0560004745 / 0560004701"},

  {wilayaCode:19, area:null, code:"19A", address:"Cité Mesoudi Edhouadi, 1014-614 logements (en face la gare Didouche Mourad)", phone:"0550428220 / 0561638678"},
  {wilayaCode:19, area:"El Eulma", code:"19B", address:"Tassahoumi, à côté de transport Hamouda et hôtel Rato, rue Touaher El Khayer, El Eulma", phone:"0561864463 / 0550428625"},
  {wilayaCode:19, area:"Aïn Oulmène", code:"19C", address:"En face CEM Douhil Abdul Hamid", phone:"0770749621 / 0770749618"},
  {wilayaCode:19, area:"Guidjel", code:"19D", address:"La zone industrielle, en face du groupe Sadi, à côté de la moussala El Takwa", phone:"0770749653 / 0555506670"},

  {wilayaCode:20, area:null, code:"20A", address:"Cité Riad, en face Maison de l'Environnement", phone:"0550428481 / 0560421128"},

  {wilayaCode:21, area:null, code:"21A", address:"Rue du Chahid Meziane Salah (route Bouyali, immeuble Guerza)", phone:"0770773555 / 0561759686 / 0560316523"},
  {wilayaCode:21, area:"Azzaba", code:"21B", address:"Cité Mefrouche Dahmane", phone:""},

  {wilayaCode:22, area:null, code:"22A", address:"Rue CPR, en face Masjid El Ansar", phone:"0770610413 / 0560419987"},

  {wilayaCode:23, area:null, code:"23A", address:"Rue Djemila, Saint Cloud (à côté de la mosquée Badr)", phone:"0561623524 / 0770582366 / 0770582331 / 0770610699"},
  {wilayaCode:23, area:"El Bouni", code:"23B", address:"Fractionnement de la Bouni 2, zone urbaine n° 43, rez-de-chaussée, section 40, groupe de propriété 02, Bouni", phone:"0770932016 / 0560777653"},

  {wilayaCode:24, area:null, code:"24A", address:"Cité 19 Juin, N° 02, en face marché El Baraka", phone:"0659698421 / 0770610741"},

  {wilayaCode:25, area:"Zouaghi", code:"25A", address:"Cité Tlemcen Zouaghi (en face de la gendarmerie)", phone:"0561850861 / 0550429556 / 0556910802 / 0560005537"},
  {wilayaCode:25, area:"Ali Mendjeli", code:"25B", address:"En face Sarl Natura Pro Algérie, entre les salles des fêtes El Baraka et Méga", phone:"0561623523 / 0770570921 / 0559006598 / 0560183481"},
  {wilayaCode:25, area:null, code:"25C", address:"Avenue Kaddour Boumedous (Ciloc), à côté de la direction régionale d'Air Algérie", phone:"0560459167 / 0560463858 / 0555508343 / 0561906766 / 0770890359"},

  {wilayaCode:26, area:null, code:"26A", address:"Cité Ennasr (près du pôle universitaire et Sonelgaz)", phone:"0770605318 / 0550429981"},

  {wilayaCode:27, area:null, code:"27A", address:"La pépinière, en face la glacière, juste à côté de la librairie Benalioua (cité Akid Amirouche, boulevard Nafoussi Othman)", phone:"0561772345 / 0561827231"},
  {wilayaCode:27, area:"Sidi Lakhdar", code:"27B", address:"Rue Si Abdellah, 01 Novembre, devant la poste Sidi Lakhder", phone:"0560264267"},

  {wilayaCode:28, area:null, code:"28A", address:"Rue Ichbilia (en face l'université de M'Sila)", phone:"0770754014 / 0561821829"},
  {wilayaCode:28, area:"Bou Saâda", code:"28B", address:"Cité El Bader (ESTTIH), à côté de l'annexe de l'APC, Bou Saâda", phone:"0559270829"},

  {wilayaCode:29, area:"Mohammadia", code:"29A", address:"Rue Larbi Ben M'hidi, à côté de l'agence de Barigou", phone:"0770582372 / 0550602272"},
  {wilayaCode:29, area:"Ville", code:"29B", address:"04 Rue Bouakkaz Ali, la zone 08, Mascara (à côté de la salle des fêtes Bent El Solana et cafétéria Ali, en face CNR Mascara)", phone:"0561680241 / 0561680236 / 0561680238"},

  {wilayaCode:30, area:null, code:"30A", address:"Sidi Abdelkader, derrière la maison de jeunes", phone:"0550602271 / 0770938789"},
  {wilayaCode:30, area:"Hassi Messaoud", code:"30B", address:"Quartier 1850, rue principale du marché hebdomadaire, en face l'ancienne agence KIA, Hassi Messaoud", phone:"0563026710 / 0563026725"},

  {wilayaCode:31, area:"Maraval", code:"31A", address:"Maraval, en face Fulla Moda, à côté de supérette El Kandi", phone:"0560239767 / 0560392373 / 0561808143 / 0561623534 / 0770171936"},
  {wilayaCode:31, area:"Bir El Djir", code:"31B", address:"Coopérative Immobilière Dar El Amel, N°14, local 1 RC", phone:"0550429662 / 0550429661"},
  {wilayaCode:31, area:"Gambetta", code:"31C", address:"Gambetta, en face arrêt de bus 51 et 11 (dispensaire Cavegay)", phone:"0560181020 / 0560181117"},
  {wilayaCode:31, area:"Arzew", code:"31D", address:"En face ancienne Daïra d'Arzew, rue Kadir El Habib N° 04, Oran", phone:"0560265681 / 0560266405"},
  {wilayaCode:31, area:"Essabah", code:"31E", address:"Coopérative Immobilière El Salam, Sidi Chami, cité Essabah, à côté du terminus du tramway", phone:"0560324392 / 0770006902"},

  {wilayaCode:32, area:null, code:"32A", address:"Cité Jolie Vue, à côté de la Direction de la distribution d'électricité et de gaz", phone:"0560481886"},

  {wilayaCode:33, area:null, code:"33A", address:"Centre-ville, quartier Bouchache, rue de la Poissonnerie", phone:"0560892842"},

  {wilayaCode:34, area:null, code:"34A", address:"Rue Tabet Salah, Bordj Bou Arreridj (devant la maison de finance)", phone:"0550428634 / 0770773018"},
  {wilayaCode:34, area:"Ras El Oued", code:"34B", address:"À l'intersection de la rue Salah Bey et de la rue Moussa N'mar, en face de la Brigade Régionale de la Gendarmerie Nationale", phone:"0770172580"},

  {wilayaCode:35, area:null, code:"35A", address:"Cité Mimouza, en face la piscine olympique, Boumerdès", phone:"0770754064 / 0770570924"},
  {wilayaCode:35, area:"Ouled Moussa", code:"35B", address:"La zone industrielle d'Ouled Moussa", phone:"0560665086"},
  {wilayaCode:35, area:"Bordj Menaïel", code:"35C", address:"Rue Madaoui Ali, local Boumzer, en face l'ophtalmologiste Dr Benmoussa Hocine, Bordj Menaïel", phone:"0563029215 / 0563029214"},
  {wilayaCode:35, area:"Dellys", code:"35D", address:"La banlieue Est de Dellys, route nationale n° 24, Rez-de-chaussée bâtiment B, local N° B05 (agence immobilière Nadji)", phone:"0560018652"},

  {wilayaCode:36, area:null, code:"36A", address:"El Tarf", phone:"0550522421 / 0550523464"},

  {wilayaCode:37, area:null, code:"37A", address:"Magasin N°03, cité Al-Qasabi, Section 14, groupement immobilier N° 165, commune de Tindouf", phone:"0560555395"},

  {wilayaCode:38, area:null, code:"38A", address:"Résidence Kaidi (promotion), ancien arrêt des taxis", phone:"0560650819 / 0555589197"},

  {wilayaCode:39, area:null, code:"39A", address:"Cité Al-Rimal, commune El Oued (la route menant au tribunal)", phone:"0550520770 / 0550521485"},

  {wilayaCode:40, area:null, code:"40A", address:"Rue du poids lourd, à côté de la clinique de dialyse Messai, Khenchela", phone:"0561759173 / 0560469790 / 0555562589"},

  {wilayaCode:41, area:null, code:"41A", address:"En face radio Souk Ahras et laboratoire des analyses Taghest", phone:"0560030559 / 0560039852"},

  {wilayaCode:42, area:null, code:"42A", address:"Cité Mohammed Bougara, à côté de l'école privée Daya School", phone:"0770580690 / 0550602568"},
  {wilayaCode:42, area:"Koléa", code:"42B", address:"Route d'Alger, Koléa, commune de Koléa, wilaya de Tipaza", phone:"0563026712 / 0563026701 / 0770170636"},

  {wilayaCode:43, area:null, code:"43A", address:"Château d'eau, en face protection civile", phone:"0550518508 / 0550518509"},
  {wilayaCode:43, area:"Chelghoum El Aïd", code:"43B", address:"Rue 1er Novembre 1954, Chelghoum El Aïd (hôtel Rhumel)", phone:"0550523511"},
  {wilayaCode:43, area:"Tadjenanet", code:"43C", address:"Rue 1er Novembre, en face CEM Mohamed Abdo", phone:"0660968179"},
  {wilayaCode:43, area:"Ferdjioua", code:"43D", address:"Rue 1er Novembre, en face l'agence d'assurances GAM", phone:"0770225873"},

  {wilayaCode:44, area:null, code:"44A", address:"Cité Najem, en face de l'entrée du groupement régional de la Gendarmerie Nationale", phone:"0561770486 / 0560607115 / 0560889758"},
  {wilayaCode:44, area:"Khemis Miliana", code:"44B", address:"Cité Ahmed Ben Abdallah, commune Khemis Miliana, wilaya de Aïn Defla", phone:"0556069297 / 0553011878"},

  {wilayaCode:45, area:"Méchéria", code:"45A", address:"Route Nationale n°06, à côté de l'hôtel Amine et du centre d'Algérie Télécom", phone:"0560294576 / 0770615202"},

  {wilayaCode:46, area:null, code:"46A", address:"22A cité des Oliviers, Aïn Témouchent 46000 (en face du parking de la wilaya)", phone:"0560908785 / 0550428624"},

  {wilayaCode:47, area:null, code:"47A", address:"Rue principale Hadj Messaoud, en face l'annexe municipale", phone:"0561686305 / 0561638680"},

  {wilayaCode:48, area:null, code:"48A", address:"Cité 31 logements, en face la justice, à côté de la banque Société Générale Algérie", phone:"0560754029 / 0560791527"},

  {wilayaCode:49, area:null, code:"49A", address:"Cité Mahdjoub, porte N°16, Timimoun, en face le stade et la SAA", phone:"0555518628"},

  {wilayaCode:51, area:null, code:"51A", address:"Rez-de-chaussée de l'hôtel Transit, à côté de la protection civile d'Ouled Djellal", phone:"0770749651"},

  {wilayaCode:52, area:null, code:"52A", address:"À côté de la wilaya de Béni Abbès, en face LAPIWI", phone:"0561906728"},

  {wilayaCode:53, area:null, code:"53A", address:"Près de la Direction des travaux publics, en face de l'entrée du radar d'Algérie Télécom", phone:"0560362803"},

  {wilayaCode:55, area:null, code:"55A", address:"Cité Sidi Abdeslam (près de la banque BEA), Touggourt", phone:"0770610683"},

  {wilayaCode:56, area:null, code:"56A", address:"Centre-ville, Tine Khatema, à côté du dentiste, Djanet", phone:"0563026716"},

  {wilayaCode:57, area:null, code:"57A", address:"Centre-ville, à côté du café Jneidi, El M'Ghair", phone:"0560143313 / 0560175370"},

  {wilayaCode:58, area:null, code:"58A", address:"Rue de l'Unité Africaine (à côté de la boulangerie Boussaïd), El Meniaa", phone:"0770602445"}
];

/* Helper: returns the list of Noest offices for a given wilaya NAME
   (matching the "name" field used in the site's WILAYAS list). */
function getOfficesForWilayaName(name){
  const code = WILAYA_OFFICIAL_CODE[name];
  if(!code) return [];
  return NOEST_OFFICES.filter(o=>o.wilayaCode===code);
}
