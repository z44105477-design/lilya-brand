// netlify/functions/send-to-noest.js
//
// This function receives the order from admin.html and forwards it to
// the courier through the free dzship unified API (https://freeship.dzbuild.com),
// which knows how to talk to NOEST Express (and other Algerian couriers)
// using the merchant's own API Token + GUID.
//
// Nothing is stored here: the request is created, forwarded, and the
// courier's response (tracking number) is returned to the admin panel.

const DZSHIP_URL = "https://freeship.dzbuild.com/v1/orders";

exports.handler = async function (event) {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: cors,
      body: JSON.stringify({ error: { message: "Method not allowed" } }),
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (e) {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ error: { message: "Invalid JSON body" } }),
    };
  }

  // Basic sanity checks before we even call the courier.
  const creds = payload.credentials || {};
  if (!creds.apiToken || !creds.guid) {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({
        error: { message: "بيانات Noest (apiToken / guid) ناقصة" },
      }),
    };
  }
  if (!payload.order || !payload.order.recipient) {
    return {
      statusCode: 400,
      headers: cors,
      body: JSON.stringify({ error: { message: "بيانات الطلب ناقصة" } }),
    };
  }

  // Force courier to "noest" regardless of what the client sent, so this
  // function can only ever be used to ship through NOEST Express.
  const forwardBody = {
    courier: "noest",
    credentials: { apiToken: creds.apiToken, guid: creds.guid },
    order: payload.order,
  };

  try {
    const upstream = await fetch(DZSHIP_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(forwardBody),
    });

    const text = await upstream.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      data = { raw: text };
    }

    if (!upstream.ok) {
      return {
        statusCode: upstream.status,
        headers: cors,
        body: JSON.stringify({
          error:
            (data && data.error) || {
              message: "تعذّر إنشاء الطلب لدى Noest Express",
            },
        }),
      };
    }

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        trackingNumber: data.trackingNumber || data.tracking || null,
        status: data.status || "created",
        raw: data,
      }),
    };
  } catch (err) {
    return {
      statusCode: 502,
      headers: cors,
      body: JSON.stringify({
        error: { message: "تعذّر الاتصال بخدمة التوصيل: " + err.message },
      }),
    };
  }
};
